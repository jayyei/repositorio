#Este es un modulo con funciones que despiden

def despedirse():
    print("Adios, me estoy despidiendo, desde la funcion despedirse del modulo adios")

class Despido():
    def __init__(self):
        print("Adios, me despido desde la clase despido en el modulo adios")