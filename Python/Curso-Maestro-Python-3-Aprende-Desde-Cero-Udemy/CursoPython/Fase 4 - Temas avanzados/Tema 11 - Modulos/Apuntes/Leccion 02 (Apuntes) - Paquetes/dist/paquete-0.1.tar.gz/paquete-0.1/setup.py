from setuptools import setup

setup(
    name="paquete",
    version="0.1",
    decription="Este es un paquete de ejemplo",
    author="Jay Sanchez",
    author_email="sanchezrj0328@gmail.com",
    scripts=[],
    packages=["paquete", "paquete.adios", "paquete.hola"]
)